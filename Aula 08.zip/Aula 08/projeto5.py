from funcoes import *

n1 = 2
n2 = 4

somar(n1,n2)
subtrair(n1,n2)
multiplicar(n1,n2)
dividir(n1,n2)