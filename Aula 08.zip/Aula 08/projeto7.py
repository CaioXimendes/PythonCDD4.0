from funcoes import imprimir_inverter_texto

imprimir_inverter_texto("ola mundo")

