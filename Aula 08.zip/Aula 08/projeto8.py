from funcoes import criar_nova_lista
a = [1,2,2,3,4,4,5,3,6,7,6,8]
criar_nova_lista(a)