from funcoes import somar

soma = somar(5,10,20,30)
print(soma)